package com.audiobridge.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket

/**
 * Foreground service that:
 *  1. Turns the MediaProjection consent result into a live MediaProjection.
 *  2. Builds an AudioPlaybackCaptureConfiguration restricted to the only
 *     usages Android allows capturing (MEDIA / GAME / UNKNOWN).
 *  3. Reads 16-bit PCM stereo @ 48kHz from AudioRecord continuously.
 *  4. Serves that raw byte stream to whoever connects to 127.0.0.1:TCP_PORT.
 *     (Not a filesystem FIFO - see README for why a cross-app FIFO write is
 *     not possible on stock, non-rooted Android, and why this loopback
 *     socket is the practical substitute requirement #7 asked for.)
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.audiobridge.app.action.START"
        const val ACTION_STOP = "com.audiobridge.app.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        const val ACTION_STATUS = "com.audiobridge.app.STATUS"
        const val EXTRA_STATUS_TEXT = "status_text"
        const val EXTRA_PEAK = "peak"

        const val TCP_PORT = 28428
        const val SAMPLE_RATE = 48000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        const val AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT

        private const val NOTIF_CHANNEL_ID = "audiobridge_capture"
        private const val NOTIF_ID = 1
        private const val TAG = "AudioBridge"
    }

    private var mediaProjection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private var captureThread: Thread? = null

    @Volatile private var clientOut: OutputStream? = null
    @Volatile private var running = false

    private val mpCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // Fires if the user revokes capture from the Quick Settings
            // "screen recording" chip, or the system tears it down. We must
            // stop cleanly here or we'd keep recording silence.
            Log.w(TAG, "MediaProjection stopped externally")
            broadcastStatus("Capture permission was revoked - stopped.")
            stopCaptureAndSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                // Must call startForeground() with the manifest-declared
                // mediaProjection type BEFORE getMediaProjection(), or
                // Android 14+ throws SecurityException.
                startForeground(NOTIF_ID, buildNotification("Starting capture..."))

                if (data == null || resultCode != Activity.RESULT_OK) {
                    broadcastStatus("Capture permission was not granted.")
                    stopCaptureAndSelf()
                    return START_NOT_STICKY
                }
                startCapture(resultCode, data)
            }
            ACTION_STOP -> stopCaptureAndSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = try {
            mpm.getMediaProjection(resultCode, data)
        } catch (e: SecurityException) {
            Log.e(TAG, "getMediaProjection failed", e)
            broadcastStatus("System refused MediaProjection: ${e.message}")
            stopCaptureAndSelf()
            return
        }
        if (mp == null) {
            broadcastStatus("Could not obtain MediaProjection.")
            stopCaptureAndSelf()
            return
        }
        mediaProjection = mp
        // Required before capturing on Android 14+; also how we learn if
        // the session dies later.
        mp.registerCallback(mpCallback, Handler(Looper.getMainLooper()))

        val config = AudioPlaybackCaptureConfiguration.Builder(mp)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AUDIO_ENCODING)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(CHANNEL_CONFIG)
            .build()

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_ENCODING)
        if (minBuf <= 0) {
            broadcastStatus("This device won't do 48kHz/16-bit/stereo capture (code $minBuf).")
            stopCaptureAndSelf()
            return
        }

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setAudioPlaybackCaptureConfig(config)
                .setBufferSizeInBytes(minBuf * 4)
                .build()
        } catch (e: Exception) {
            // Covers SecurityException (permission/consent issues) and
            // IllegalArgumentException/IllegalStateException from a bad config.
            Log.e(TAG, "AudioRecord.Builder.build() failed", e)
            broadcastStatus("Failed to create AudioRecord: ${e.message}")
            stopCaptureAndSelf()
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            broadcastStatus("AudioRecord failed to initialize.")
            record.release()
            stopCaptureAndSelf()
            return
        }
        audioRecord = record

        try {
            val ss = ServerSocket(TCP_PORT, 1, InetAddress.getByName("127.0.0.1"))
            ss.reuseAddress = true
            serverSocket = ss
        } catch (e: IOException) {
            Log.e(TAG, "Could not bind 127.0.0.1:$TCP_PORT", e)
            broadcastStatus("Could not open port $TCP_PORT: ${e.message}")
            record.release()
            audioRecord = null
            stopCaptureAndSelf()
            return
        }

        running = true
        record.startRecording()
        if (record.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            broadcastStatus("AudioRecord.startRecording() did not start.")
            stopCaptureAndSelf()
            return
        }

        updateNotification("Waiting for Termux on 127.0.0.1:$TCP_PORT")
        broadcastStatus("Capturing. Waiting for Termux to connect on port $TCP_PORT ...")

        acceptThread = Thread(::acceptLoop, "AudioBridge-accept").apply { isDaemon = true; start() }
        captureThread = Thread(::captureLoop, "AudioBridge-capture").apply { isDaemon = true; start() }
    }

    /** Accepts (and re-accepts, if Termux's nc/socat restarts) one client at a time. */
    private fun acceptLoop() {
        val ss = serverSocket ?: return
        while (running) {
            try {
                val socket = ss.accept()
                socket.tcpNoDelay = true
                synchronized(this) {
                    try { clientOut?.close() } catch (_: IOException) {}
                    clientOut = socket.getOutputStream()
                }
                Log.i(TAG, "Termux client connected")
                updateNotification("Streaming PCM to Termux")
                broadcastStatus("Streaming PCM to Termux.")
            } catch (e: IOException) {
                if (running) Log.w(TAG, "accept() failed: ${e.message}")
            }
        }
    }

    /**
     * Always drains AudioRecord, whether or not a client is currently
     * connected, so the capture buffer never overflows and Termux can
     * disconnect/reconnect (e.g. after `q` in cava) without us wedging.
     */
    private fun captureLoop() {
        val record = audioRecord ?: return
        val buffer = ByteArray(4096)
        while (running) {
            val read = try {
                record.read(buffer, 0, buffer.size)
            } catch (e: Exception) {
                Log.e(TAG, "AudioRecord.read failed", e)
                broadcastStatus("Audio read error: ${e.message}")
                break
            }
            if (read <= 0) continue

            var peak = 0
            var i = 0
            while (i + 1 < read) {
                val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toInt()
                val abs = if (sample < 0) -sample else sample
                if (abs > peak) peak = abs
                i += 2
            }
            broadcastPeak(peak)

            val out = clientOut
            if (out != null) {
                try {
                    out.write(buffer, 0, read)
                } catch (e: IOException) {
                    synchronized(this) {
                        try { out.close() } catch (_: IOException) {}
                        clientOut = null
                    }
                    Log.w(TAG, "Termux client disconnected")
                    updateNotification("Waiting for Termux on 127.0.0.1:$TCP_PORT")
                    broadcastStatus("Client disconnected. Waiting on port $TCP_PORT ...")
                }
            }
        }
    }

    private fun broadcastPeak(peak: Int) {
        sendBroadcast(Intent(ACTION_STATUS).putExtra(EXTRA_PEAK, peak).setPackage(packageName))
    }

    private fun broadcastStatus(text: String) {
        sendBroadcast(Intent(ACTION_STATUS).putExtra(EXTRA_STATUS_TEXT, text).setPackage(packageName))
    }

    private fun stopCaptureAndSelf() {
        running = false
        try { serverSocket?.close() } catch (_: IOException) {}
        serverSocket = null
        try { clientOut?.close() } catch (_: IOException) {}
        clientOut = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        audioRecord?.release()
        audioRecord = null
        try { mediaProjection?.unregisterCallback(mpCallback) } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        stopCaptureAndSelf()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            NOTIF_CHANNEL_ID, "Audio capture", NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, NOTIF_CHANNEL_ID)
            .setContentTitle("Audio Bridge")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(0, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }
}
