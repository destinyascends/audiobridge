package com.audiobridge.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

/**
 * Deliberately plain android.app.Activity (no androidx.activity result
 * contracts) so the project has zero AndroidX dependencies to resolve
 * during an on-device build. startActivityForResult/onActivityResult and
 * requestPermissions/onRequestPermissionsResult are framework APIs
 * available since API 23 - fully supported, just pre-AndroidX style.
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var peakText: TextView

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            intent.getStringExtra(CaptureService.EXTRA_STATUS_TEXT)?.let {
                statusText.text = it
            }
            val peak = intent.getIntExtra(CaptureService.EXTRA_PEAK, -1)
            if (peak >= 0) {
                val pct = (peak * 100 / 32767).coerceIn(0, 100)
                peakText.text = "Peak level: $pct%"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        peakText = findViewById(R.id.peakText)
        val startButton: Button = findViewById(R.id.startButton)
        val stopButton: Button = findViewById(R.id.stopButton)

        startButton.setOnClickListener { onStartClicked() }
        stopButton.setOnClickListener { onStopClicked() }

        statusText.text = "Idle. Tap Start, grant the permissions, then connect from Termux."
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(CaptureService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(statusReceiver)
    }

    private fun onStartClicked() {
        // Order matters: POST_NOTIFICATIONS -> RECORD_AUDIO -> MediaProjection
        // consent. All three must be settled before we touch AudioRecord.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_RECORD_AUDIO)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // Shows the system "Start recording or casting?" dialog. Required by
        // the AudioPlaybackCapture API even though we only want audio.
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            REQ_NOTIF -> onStartClicked() // continue the chain regardless; notif just won't show if denied
            REQ_RECORD_AUDIO -> {
                if (granted) onStartClicked()
                else statusText.text = "RECORD_AUDIO permission is required to capture audio."
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJECTION) return

        if (resultCode != RESULT_OK || data == null) {
            statusText.text = "Capture permission was denied."
            return
        }

        val startIntent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        // startForegroundService is required on O+ so the service has a
        // small time budget to call startForeground() before it's killed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(startIntent)
        } else {
            startService(startIntent)
        }
        statusText.text = "Starting capture..."
    }

    private fun onStopClicked() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        statusText.text = "Stopped."
        peakText.text = "Peak level: --"
    }

    companion object {
        private const val REQ_NOTIF = 100
        private const val REQ_RECORD_AUDIO = 101
        private const val REQ_PROJECTION = 102
    }
}
