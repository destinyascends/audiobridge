#!/data/data/com.termux/files/usr/bin/bash
# Starts the Termux-side half of the bridge:
#   127.0.0.1:28428 (Android app) --nc--> ~/audiobridge.fifo (cava reads this)
#
# Prerequisites (one-time): pkg install netcat-openbsd
# Run this AFTER tapping "Start capture" in the Audio Bridge app.

set -e

FIFO="$HOME/audiobridge.fifo"
PORT=28428

if [ ! -p "$FIFO" ]; then
    mkfifo "$FIFO"
    echo "Created FIFO at $FIFO"
fi

if pgrep -f "nc 127.0.0.1 $PORT" > /dev/null; then
    echo "Relay already running."
    exit 0
fi

echo "Starting relay: 127.0.0.1:$PORT -> $FIFO"
echo "(This will sit quietly until you also run cava - that's expected, they unblock each other.)"
nc 127.0.0.1 "$PORT" > "$FIFO" &
disown
echo "Relay started (background). Now run: cava -p $HOME/.config/cava/config"
