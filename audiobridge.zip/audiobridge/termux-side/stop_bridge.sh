#!/data/data/com.termux/files/usr/bin/bash
# Stops the Termux-side relay. Also stop cava separately (q or Ctrl+C in its
# terminal), and tap "Stop capture" in the app (or use the notification's
# Stop action) to release the microphone-equivalent capture and MediaProjection.

PORT=28428

PIDS=$(pgrep -f "nc 127.0.0.1 $PORT" || true)
if [ -n "$PIDS" ]; then
    kill $PIDS
    echo "Stopped relay (pid: $PIDS)."
else
    echo "No relay process found."
fi

# Not deleting the FIFO by default so it can be reused next run.
# Uncomment to remove it too:
# rm -f "$HOME/audiobridge.fifo"
