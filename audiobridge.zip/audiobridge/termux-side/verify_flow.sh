#!/data/data/com.termux/files/usr/bin/bash
# Sanity check independent of cava: connects directly to the app's socket
# for 5 seconds and counts bytes received.
#
# Expected byte count at 48000 Hz, 16-bit, stereo, for N seconds:
#   48000 * 2 channels * 2 bytes/sample * N seconds
# For 5 seconds that's ~960000 bytes. This confirms the pipeline is wired
# correctly (the byte RATE is right) even if the source app is currently
# silent - it does not by itself prove there's audible audio, only that
# PCM frames of the right size/rate are arriving.
#
# NOTE: run this BEFORE start_bridge.sh/cava, or stop them first - the
# server only serves one client connection at a time and this will steal it.

PORT=28428
echo "Connecting to 127.0.0.1:$PORT for 5 seconds..."
BYTES=$(timeout 5 nc 127.0.0.1 "$PORT" | wc -c)
echo "Received: $BYTES bytes"
echo "Expected (silence or audio, same either way): ~960000 bytes for 5s @ 48kHz/16-bit/stereo"
if [ "$BYTES" -lt 500000 ]; then
    echo "WARNING: far fewer bytes than expected. Check that:"
    echo "  - the app shows 'Capturing' / 'Waiting for Termux'"
    echo "  - something is actually playing (e.g. YouTube), not just Spotify (Spotify blocks capture)"
fi
